Rappid
======

The HTML 5 diagramming toolkit.


List of modules
---------------

- Halo: element tools
- Stencil: element palette
- SelectionView: working with selections
- PaperScroller: paper scroll & pan
- Clipboard: copy-pasting with localStorage support
- Inspector: presentation and data-attributes edior/viewer
- FreeTransform: element resizing to all the sides
- Tooltip: display information messages anywhere in the UI
- Command: command manager, undo/redo facility
- Validator: define validation rules for a diagram
- ForceDirected: force-directed auto-layout of graphs
- GridLayout: auto-layout of graphs into a grid
- Gexf: GEXF format conversion
- SVG: client side export into the SVG vector format
- Raster: client side export into a raster format (PNG, JPEG)
- Print: automatic preparation of paper for printing via browser print dialog
- Channel: real-time synchronization of graphs between server and (possibly multiple) clients (real-time collaboration)
- KitchenSink: Kitchen sink application to get you started quickly
- Rappid: a more elaborate diagramming application


Directory structure
-------------------

dist/   ... Contains distribution files of JointJS core library and all the plugins.
plugins/  ... Contains the source code and other related files to all the plugins.
src/   ... Contains source files of the JointJS core library.
KitchenSink/ ... An example application.
Rappid/ ... A more elaborate application.


Documentation
-------------

Online documentation to all the plugins is located at the http://jointjs.com/rappid/docs.


Quick start
-----------

Probably the best way to start is by opening the KitchenSink/index.html in your browser and studying
the KitchenSink/main.js file. The KitchenSink application serves as a reference for using the plugins
and how they can be combined. A more elaborate and useful application is in the Rappid/ directory.
Just open Rappid/index.html file in your browser. This application is more advanced than the KitchenSink
application.


Notes
-----

Some plugins (e.g. Halo and Stencil) contain Handlebars templates (http://handlebarsjs.com) that,
when their adjustments are desired, need to be compiled. All such plugins contain a build file - Gruntfile.js (http://gruntjs.com).
This grunt build file makes it easy to create the distribution JavaScript/CSS files needed when using those plugins.
In order to build the distribution files, one needs to have NodeJS (http://nodejs.org) and grunt-cli (https://github.com/gruntjs/grunt-cli)
installed. After that, run once `npm install` in the plugin directory (where the package.json file is located) in order to install all the dependencies.
Making the build is then a matter of running `grunt` on the command line in the plugin directory (where the Gruntfile.js is located).


Support
-------

Please use our JointJS_plus repository on Github to file bugs and feature requests:
https://github.com/clientIO/JointJS_plus/issues. We cannot guarantee a response time but we'll
do our best to fix bugs as soon as we can. A commercial support is available as well
(see the http://jointjs.com/support page). If you have any questions, drop us an email
at org@client.io.


License
-------

Rappid is licensed under the Rappid License. Please see the LICENSE file for the full license.

Copyright (c) 2014 client IO
