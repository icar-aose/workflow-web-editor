// starts with index.js in halo plugin

var commandManager = new joint.dia.CommandManager({
    graph: graph
});
