new joint.ui.Tooltip({
    target: '.top-tooltip',
    content: 'Top directed tooltip.',
    top: '.top-tooltip',
    direction: 'top'
});

new joint.ui.Tooltip({
    target: '.left-tooltip',
    content: 'Left directed tooltip.',
    left: '.left-tooltip',
    direction: 'left'
});

new joint.ui.Tooltip({
    target: '.right-tooltip',
    content: 'Right directed tooltip.',
    right: '.right-tooltip',
    direction: 'right'
});

new joint.ui.Tooltip({
    target: '.bottom-tooltip',
    content: 'Bottom directed tooltip.',
    bottom: '.bottom-tooltip',
    direction: 'bottom'
});